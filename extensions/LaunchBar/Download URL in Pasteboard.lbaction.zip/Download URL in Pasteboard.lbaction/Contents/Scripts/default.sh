#!/bin/sh
#
# LaunchBar Action Script
#

open "okjson://download"